function validateBillingInfo() {
    console.log("Validating billing info...");
}

export function processPayment(){
    console.log("processing payment...");
}