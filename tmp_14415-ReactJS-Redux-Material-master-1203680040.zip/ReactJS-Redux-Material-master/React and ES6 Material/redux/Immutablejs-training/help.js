Immutable JS:
-------------
npm init -y      (create package.json)