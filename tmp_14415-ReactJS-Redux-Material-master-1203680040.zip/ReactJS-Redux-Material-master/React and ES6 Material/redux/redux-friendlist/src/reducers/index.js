export { default as friendlist } from './friendlist';
