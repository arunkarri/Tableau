import React from 'react';

class Service extends React.Component{
  render() {
      return (
        <div>
          <h2>Services</h2>
          <p>We offer training in following technologies</p>
          <ol>
            <li>Complete Microsoft .Net (.Net 4.5.3)</li> 
            <li>React with Redux</li>
            <li>Angular 2 with Typescript</li>
            <li>Node JS</li>
            <li>Grunt, Gulp, webpack..</li>
          </ol>
        </div>
      );
    }
};
export default Service

