import React from 'react';

class Contact extends React.Component{
  render() {
      return (
        <div>
          <h2>For Any queries Kindly contact</h2>
          <p>Murthy Srirama . Cell : 98480 11641
          or mail  to dsrmurthy786@yahoo.com
          </p>
        </div>
      );
    }
};
export default Contact