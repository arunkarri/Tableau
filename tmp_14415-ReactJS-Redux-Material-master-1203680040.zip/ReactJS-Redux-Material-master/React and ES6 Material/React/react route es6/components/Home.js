import React from 'react';

class Home extends React.Component{
  render() {
      return (
        <div>
          <h2>Pratibha Infotek Welcome's you</h2>
           <p>We offer corporate training services online for Microsoft<br/>
             Technology and UI technology at global level with highly <br/>
             experienced faculty . 
          </p>
  
          <p>Quality servie is our motto</p>
        </div>
      );
    }
};
export default Home