
import React from 'react';
class App extends React.Component {
   render() {
      return (
         <div>
            Welcome to React world with  Webpack by Murthy!
         </div>
      );
   }
}
export default App;