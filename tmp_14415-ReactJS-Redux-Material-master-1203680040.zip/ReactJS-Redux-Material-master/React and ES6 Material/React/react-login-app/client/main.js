import React from 'react';
import ReactDOM from 'react-dom';
import App from '../components/App'


ReactDOM.render(<App
				 title="Murthy Shopping Mall"
				 subtitle="We promise Quality products"/>,
	document.getElementById('app'))

