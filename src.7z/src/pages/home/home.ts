import { Component,Input } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {  OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,ValidatorFn,AbstractControl,NgForm } from '@angular/forms';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  styles: ['.error{ color:red; padding-left: 16px; }']
})
export class HomePage {

  public showItem: any;
  public icons: any;
  public countryCodes: any;
  public telNumber: any;
  public country: String;
  user: FormGroup;
  
  constructor(public navCtrl: NavController,private http: Http) {
    this.icons= 'mail';
    this.showItem= 'mail';
    this.country='';
    this.countryCodes= [ {
          "name": "United States",
          "dial_code": "+1",
          "code": "US"
      }, {
          "name": "Israel",
          "dial_code": "+972",
          "code": "IL"
      }, {
        "name": "Afghanistan",
        "dial_code": "+93",
        "code": "AF"
    }, {
        "name": "Albania",
        "dial_code": "+355",
        "code": "AL"
    }];

  }
  ngOnInit() {
   this.getOrderSummary();

    this.user = new FormGroup({
    email: new FormControl('', [Validators.required,Validators.email])
    });
    
    }

  public myContent(tab) {
    this.showItem= tab;
  }
  public selCountry(obj){
    console.log(obj);
    this.telNumber= obj.dial_code;
  }
  public getOrderSummary(): Observable<any> {
    console.log("hi");
    // get users from api
    return this.http.get('../../assets/data/country.json')//, options)
        .map((response: Response) => {
            console.log("mock data" + response.json());
            this.countryCodes= response.json();
        }
    )
  }
}
